<html>
</body>
<font face="Arial" size="2">
<?

//Class Importing and creation.
require("QueryString.php");
$qsc = new QueryString();

//This is the real query string
$qs = $QUERY_STRING;
echo "<b>This page QS: </b>[" . $qs . "]<br><br>";

//Example query string
$qs = "var1=banana&var2=apple&var2=coffee&&var3=hq@usa.net";
echo "<b>Example QS: </b>[" . $qs . "]<br><br>";

//New value of a variable
echo "<b>Setting var1: </b>" . $qsc->setVar($qs, "var1", "newValue1") . "<br>" ;
echo "<b>Setting var2 (repeated): </b>" . $qsc->setVar($qs, "var2", "2") . "<br>" ;
echo "<b>Setting var6 (non-existent): </b>" . $qsc->setVar($qs, "var6", "6") . "<br><br>" ;

//Array of new value of a variable
$array = Array("var1"=>1, "var2"=>2, "var6"=>6);
echo '<b>Setting Array("var1"=>1, "var2"=>2, "var6"=>6): </b>' . $qsc->setVarArray($qs, $array) . "<br><br>" ;

//Declaration of a variable
echo "<b>Declaration of var2: </b>" . $qsc->getVar($qs, "var2") . "<br><br>";

//Value of a variable by name
echo "<b>Value of var2: </b>" . $qsc->getVarValue($qs, "var2") . "<br><br>";

//Deleting a variable
echo "<b>Deleting All var2: </b>" . $qsc->delVar($qs, "var2") . "<br><br>";

//Value a variable by position
echo "<b>Values of vars at 2nd position: </b>" . $qsc->getVarPosValue($qs, 2) . "<br><br>";

//Query String to an Array
echo "<b>The Query String Array: </b>";
print_r($qsc->toArray($qs));
echo "<br><br>";

?>
</font>
</body>
</html>